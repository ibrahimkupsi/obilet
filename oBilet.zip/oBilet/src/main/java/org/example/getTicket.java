package org.example;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class getTicket {

    WebDriver driver = new ChromeDriver();


    public void openPage(){
        System.setProperty("chrome","/drivers/chromedriver");
        driver.get("https://www.obilet.com/");
        driver.manage().window().maximize();
        Assert.assertEquals(driver.getCurrentUrl(),"https://www.obilet.com/");
    }

    public void loginPage(){
        try {
            Thread.sleep(1000);
            driver.findElement(By.className("login")).click();
            Thread.sleep(1000);
        } catch (InterruptedException exception) {
            exception.printStackTrace();
        }
    }

    public void clickSignUp(){
        try {
            Thread.sleep(1000);
            driver.findElement(By.xpath("//*[@data-event-label='Clicked on sign-up']")).click();
            Thread.sleep(1000);
        } catch (InterruptedException exception) {
            exception.printStackTrace();
        }
    }

    public void signUpWithEmail(){
        try {
            driver.findElement(By.xpath("//*[@type='email']")).sendKeys("***@gmail.com");
            driver.findElement(By.xpath("//*[@type='password']")).sendKeys("***");
            driver.findElement(By.className("register-button")).click();
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        Assert.assertEquals(driver.getCurrentUrl(),"https://www.obilet.com/?kayit");
    }

    public void searchTicket(){
        try {
            Thread.sleep(1000);
            driver.findElement(By.linkText("Uçak")).click();
            Thread.sleep(1000);

        }catch (Exception exception) {
            exception.printStackTrace();
        }
        Assert.assertEquals(driver.getCurrentUrl(),"https://www.obilet.com/ucak-bileti");
    }

    public void flight(){
        try {
            Thread.sleep(1000);
            driver.findElement(By.id("origin-input")).click();
            Thread.sleep(1000);
            driver.findElement(By.xpath("//*[@data-value='350_67']")).click();
            Thread.sleep(1000);
            driver.findElement(By.id("destination-input")).click();
            Thread.sleep(1000);
            driver.findElement(By.xpath("//*[/html/body/main/div[1]/div/form/div[1]/div[2]/div/ob-select/div/ul/li[7]]")).click();
            Thread.sleep(1000);
            driver.findElement(By.id("departure-input")).click();
            Thread.sleep(1000);
            driver.findElement(By.xpath("//*[@data-date='2023-03-09']")).click();
            Thread.sleep(1000);
            driver.findElement(By.id("return-input-placeholder")).click();
            Thread.sleep(1000);
            driver.findElement(By.xpath("//*[@data-date='2023-04-13']")).click();
            Thread.sleep(1000);
            driver.findElement(By.id("search-button")).click();
            Thread.sleep(1000);
            Assert.assertEquals(driver.getCurrentUrl(),"https://www.obilet.com/ucuslar/350_67-223_5/20230309-20230413/1a/economy/all");
        }catch (Exception exception) {
            exception.printStackTrace();
        }

    }

    public void choiseFly(){
        try {
            Thread.sleep(1000);
            driver.findElement(By.xpath("/html/body/main/div[7]/ul/li[1]")).click();
            Thread.sleep(1000);
            driver.findElement(By.xpath("/html/body/main/div[8]/ul/li[1]")).click();
            Thread.sleep(1000);

        }catch (Exception exception) {
            exception.printStackTrace();
        }
        Assert.assertEquals(driver.getCurrentUrl(),"https://www.obilet.com/ucak-bileti/odeme/350_67-223_5/20230309-20230413/1a/economy/SAW-AYT-20230309--1006PC--1006PC-2028-1/AYT-SAW-20230413--1006PC--1006PC-2005-1");

    }

}
