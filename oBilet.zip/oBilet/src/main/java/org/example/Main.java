package org.example;


public class Main {
    public static void main(String[] args) {

       getTicket getTicket = new getTicket();
        getTicket.openPage();
        getTicket.loginPage();
        getTicket.clickSignUp();
        getTicket.signUpWithEmail();
        getTicket.searchTicket();
        getTicket.flight();
        getTicket.choiseFly();
    }
}